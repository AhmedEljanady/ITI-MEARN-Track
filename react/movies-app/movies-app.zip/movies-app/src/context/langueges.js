import React from "react";

export const langContext = React.createContext();
export const LangProvieder = langContext.Provider;
